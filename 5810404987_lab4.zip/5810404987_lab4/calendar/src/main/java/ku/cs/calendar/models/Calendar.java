package ku.cs.calendar.models;

import java.util.ArrayList;

import ku.cs.calendar.controllers.DatabaseController;

/**
 * Natchaneeya Srithanavanich 5810404987
 */

public class Calendar {
	private ArrayList<Event> myCalendar;
	private Event event;
//	private DatabaseController db = new DatabaseController();

	public Calendar() {
		myCalendar = new ArrayList<>();
		
	}
	public void addEvent(Event event){
		this.event = event;
		myCalendar.add(event);
//		db.insert(event.getDate().getDay(), event.getDate().getMonth(),event.getDate().getYear(), event.getTime().getHr(), event.getTime().getMin(), event.getDate().getInfo());
		
	}

	public void editEvent(Event event){
		
	}
	
	public void delEvent(Event event){
		for (int i = 0; i < myCalendar.size(); i++) {
			if (event.getDate().getDay() == myCalendar.get(i).getDate().getDay() &&
					event.getDate().getMonth().equals(myCalendar.get(i).getDate().getMonth()) &&
					event.getDate().getYear() == myCalendar.get(i).getDate().getYear() &&
					event.getTime().getHr().equals(myCalendar.get(i).getTime().getHr()) &&
					event.getTime().getMin().equals(myCalendar.get(i).getTime().getMin()) &&
					event.getDate().getInfo().equals(myCalendar.get(i).getDate().getInfo()) ){
				myCalendar.remove(i);
//				db.delete(event.getDate().getDay(), event.getDate().getMonth(),event.getDate().getYear(), event.getTime().getHr(), event.getTime().getMin(), event.getDate().getInfo());
			}
		}
	}
	public String show(){
		return String.format("%s : %s  %s",event.getTime().getHr(), event.getTime().getMin(), event.getDate().getInfo());
	}
	
	public ArrayList<Event> getMyCalendar() {
		return myCalendar;
	}
	
	
}
