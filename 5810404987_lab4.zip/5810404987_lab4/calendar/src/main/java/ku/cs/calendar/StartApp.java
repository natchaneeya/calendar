package ku.cs.calendar;

import ku.cs.calendar.controllers.MainController;

/**
 * Natchaneeya Srithanavanich 5810404987
 */
public class StartApp {

	public static void main(String[] args) {
		MainController main = new MainController();
		main.startApplication();
		

		

	}

}
