package ku.cs.calendar.models;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
/**
 * Natchaneeya Srithanavanich 5810404987
 */
public class Time {
	private String hr;
	private String min;
	
	public Time(String hr, String min) {
		this.hr = hr;
		this.min = min;
	}
	public String getHr() {
		return hr;
	}
	public String getMin() {
		return min;
	}
	
	

}
